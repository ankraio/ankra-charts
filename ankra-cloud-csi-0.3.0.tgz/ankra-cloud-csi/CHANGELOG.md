# ankra-cloud-csi changelog

All notable changes to this chart will be documented in this file. Format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the chart
uses [Semantic Versioning](https://semver.org/).

The chart is maintained in [`ankraio/ankra-cloud-csi`](https://github.com/ankraio/ankra-cloud-csi)
(`charts/ankra-cloud-csi`) and copied here for each release; `appVersion` is the
driver image tag it installs.

## [Unreleased]

## [0.3.0] - 2026-11-03

### Added

- Storage capacity tracking. The CSIDriver sets `storageCapacity: true` and the
  controller's external-provisioner runs with `--enable-capacity`
  (`--capacity-ownerref-level=2`, so the `CSIStorageCapacity` objects are owned by
  the controller Deployment), publishing one per node and StorageClass from the
  driver's new `GetCapacity`. The scheduler then binds a `WaitForFirstConsumer`
  claim only to a node with room for it. For `local-nvme` the capacity is the room
  left in the Ankra Local pool of the node's compute node, as the Ankra Cloud API
  computes it with the rule that refuses a volume with `409 the node's Ankra Local
  pool takes no new volumes`; before, a claim could be bound to a full node and
  wait until other volumes were deleted (15 to 19 minutes for CI workspaces on
  ankra-ci-sto1). Other tiers report the largest volume the API takes.
- Values `capacity.enabled` (default `true`), `capacity.pollInterval` (`30s`) and
  `capacity.cacheTTL` (`10s`, passed to the driver as `--capacity-cache-ttl`).
- A namespaced Role and RoleBinding for the controller: `csistoragecapacities`,
  and `get` on pods and ReplicaSets to find the owning Deployment.

### Changed

- Driver image `v0.3.0`, which needs the Ankra Cloud API's
  `GET /v1/servers/{id}/storage-capacity`. Against an API without it the driver
  reports every node as able to take the largest volume, as before capacity
  tracking. It keeps the Go 1.26.10 build of 0.2.2 and the `ResourceExhausted`
  answer of 0.2.3 for a node whose pool is full, which stays the fallback when
  two claims race for the last room on one host.

## [0.2.3] - 2026-11-02

### Fixed

- A local-nvme volume whose selected node sits on a host whose Ankra Local pool
  takes no new volumes now fails `CreateVolume` with `ResourceExhausted` instead
  of `FailedPrecondition`. external-provisioner then drops the PVC's selected
  node and the scheduler places the pod on a node whose host has room; before,
  the pod stayed Pending on the full node. Other conflicts keep
  `FailedPrecondition`.

## [0.2.2] - 2026-10-31

### Fixed

- Release builds use the digest-pinned Go 1.26.10 toolchain (GO-2026-6809) and
  golang.org/x/net 0.62.0 (GO-2026-6860, GO-2026-6866). No storage class,
  credential or volume configuration changes.

## [0.2.1] - 2026-10-31

### Fixed

- The driver's API client health-checks its HTTP/2 connection: a connection that
  stops answering is pinged after 15 seconds without a frame and closed when the
  ping goes unanswered for 10 seconds, so the next call dials a fresh one. Before,
  every call kept going onto the dead connection and timed out for minutes, and
  volumes stayed `Pending` the whole time. Image `v0.2.1`; no values or template
  changes.

## [0.2.0] - 2026-10-10

### Fixed

- A `local-nvme` volume is created on the compute node that runs the scheduled
  node's server (`create_storage` `placement.server_id`), so attaching it no
  longer fails with 409 Conflict.

### Changed

- The default StorageClass is the new `ankra-default`: it names no tier, so every
  volume gets its zone's default storage tier and a claim without a class works in
  a zone without Ankra Storage, where only `local-nvme` is offered.
  `ankra-standard` stays, no longer the default.
- Driver image `share.ankra.cloud/library/ankra-cloud-csi:v0.2.0`; the API client
  is regenerated from the current Ankra Cloud OpenAPI document.

## [0.1.0] - 2026-09-28

### Added

- First public release of the Ankra Cloud CSI driver `csi.ankra.cloud` (image
  `share.ankra.cloud/library/ankra-cloud-csi:v0.1.0`, linux/amd64 and linux/arm64):
  dynamic provisioning for the `standard`, `maxiops`, `hdd` and `local-nvme` tiers,
  hot-plug attach and detach, online expansion, snapshots, restore and clones.
- StorageClasses `ankra-standard` (default), `ankra-maxiops`, `ankra-hdd` and
  `ankra-local-nvme`, all `WaitForFirstConsumer`; the `ankra-snapshots`
  VolumeSnapshotClass when the snapshot API is served.
