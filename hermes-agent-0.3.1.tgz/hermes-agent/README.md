# hermes-agent

Nous Research [Hermes Agent](https://github.com/NousResearch/hermes-agent) on
Kubernetes, packaged the way Ankra runs it: image pinned by digest, credentials
that have to come from a Secret you already manage, and a NetworkPolicy that
keeps the agent away from the cluster network and the cloud metadata endpoint.

Hermes is an agent that runs a shell and a browser. Treat it as untrusted
workload that happens to hold your model provider keys, and the defaults in this
chart make sense.

| | |
|---|---|
| Chart | `oci://ghcr.io/ankraio/ankra-charts/hermes-agent` |
| Helm repo | `helm repo add ankra https://ankraio.github.io/ankra-charts` |
| Image | `docker.io/nousresearch/hermes-agent`, digest-pinned in `values.yaml` |
| Upstream project | [NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent) |

## Install

Hermes needs at least one model provider key. The chart will not accept it as a
plain value, so create the Secret first:

```bash
kubectl create namespace hermes
kubectl -n hermes create secret generic hermes-credentials \
  --from-literal=OPENROUTER_API_KEY="$OPENROUTER_API_KEY"

helm install hermes oci://ghcr.io/ankraio/ankra-charts/hermes-agent \
  --version 0.1.1 -n hermes \
  --set secrets.existingSecret=hermes-credentials
```

Any environment variable Hermes reads can live in that Secret - every key is
loaded with `envFrom`. The commonly used ones:

| Purpose | Keys |
|---|---|
| Model providers | `OPENROUTER_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GOOGLE_API_KEY`, `GEMINI_API_KEY`, `GROQ_API_KEY`, `MISTRAL_API_KEY`, `NOUS_API_KEY`, `HF_TOKEN` |
| Tools | `EXA_API_KEY`, `FIRECRAWL_API_KEY`, `FAL_KEY`, `BROWSERBASE_API_KEY`, `BROWSERBASE_PROJECT_ID`, `GITHUB_TOKEN` |
| Chat surfaces | `TELEGRAM_BOT_TOKEN`, `DISCORD_BOT_TOKEN`, `SLACK_BOT_TOKEN`, `SLACK_APP_TOKEN`, `SIGNAL_HTTP_URL` |
| API server | `API_SERVER_KEY` |

Overlays for the usual shapes live in [`values-examples/`](values-examples):
`minimal`, `production`, `air-gapped`, `multi-tenant`, `operator`.

## What the defaults enforce

Every rule below fails `helm template`/`helm install` with an explanation rather
than shipping a weaker manifest. Each has a named waiver under `hardening.*`, so
loosening one is a visible line in your values file.

| Rule | Waiver |
|---|---|
| The image is pinned by digest, not just by tag | `hardening.allowMutableImageTag` |
| API keys come from `secrets.existingSecret` or an ExternalSecret, never inline values | `hardening.allowInlineSecrets` |
| The agent drops to a non-root uid (`env.HERMES_UID`), read-only root filesystem, `ALL` capabilities dropped, no privilege escalation, no added capabilities | `hardening.allowPrivilegedRuntime` |
| `runAsUser` is not pinned, and `runAsNonRoot: true` is refused — see below | `hardening.enabled: false` |
| No ServiceAccount token mounted - Hermes never calls the Kubernetes API | `hardening.allowPrivilegedRuntime` |
| `rbac.rules` may not contain `*` | `hardening.allowWildcardRbac` |
| A NetworkPolicy is present | `hardening.allowUnrestrictedNetwork` |
| Egress excludes `169.254.0.0/16` (cloud instance metadata) | `hardening.allowMetadataEndpointEgress` |
| Egress excludes RFC1918 (`10/8`, `172.16/12`, `192.168/16`) | `hardening.allowClusterInternalEgress` |
| `apiServer.corsOrigins` is not `*` | none - list the origins |
| One replica and a `Recreate` rollout while persistence is on | none - `HERMES_HOME` is single-writer |
| npm packages install only when `npm.enabled=true`, and never run lifecycle scripts | `npm.ignoreScripts` |

`hardening.enabled=false` turns all of it off at once. It exists for local
experiments and is not a supported way to run this chart.

### Why the pod enters as root

The upstream image runs `s6-overlay` as PID 1, and its bootstrap refuses a
pinned non-root UID outright:

```
[stage2] ERROR: container started with --user 1000 (an arbitrary, non-hermes UID).
... the baked /opt/hermes install tree is intentionally root-owned and
non-writable, so a pinned --user UID cannot repair startup state
```

Its supported model is the inverse: enter as root, remap the `hermes` user to
`HERMES_UID`/`HERMES_GID`, chown the data volume, then drop to that user. So the
chart sets `env.HERMES_UID: "1000"` and does **not** set `runAsUser`; the
hardening guard checks that `HERMES_UID` is non-zero rather than asserting
`runAsNonRoot`, and pinning a UID is refused at render time with this reason.

Two consequences:

- The namespace needs PodSecurity **`baseline`**, not `restricted`.
- The root filesystem still stays read-only. s6-overlay only needs a writable
  `/run`, which the chart mounts as an emptyDir with `S6_READ_ONLY_ROOT=1`.
- Four capabilities are added back on top of `drop: [ALL]`: `CHOWN`,
  `DAC_OVERRIDE`, `SETGID`, `SETUID`. s6-overlay needs them to chown its service
  directories and setuid into the hermes user. Without them the agent is dead
  but the pod still reports Ready, because s6 keeps PID 1 alive. Verified
  minimal against the image; the guard rejects anything beyond these four.

### The network default, concretely

```yaml
egress:
  - to: [{ namespaceSelector: { matchLabels: { kubernetes.io/metadata.name: kube-system } } }]
    ports: [{ protocol: UDP, port: 53 }, { protocol: TCP, port: 53 }]
  - to:
      - ipBlock:
          cidr: 0.0.0.0/0
          except: [10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16, 100.64.0.0/10, 127.0.0.0/8]
    ports: [{ protocol: TCP, port: 443 }]
```

DNS, and HTTPS to public addresses. That is enough to reach OpenRouter,
Anthropic, OpenAI and the usual tool APIs, and not enough to reach your
in-cluster Postgres, another tenant's pods, or the instance metadata service
that hands out node IAM credentials.

Ingress is denied unless a Service is exposed, in which case only the release
namespace (plus `networkPolicy.ingress.allowedNamespaces`) reaches the exposed
ports.

Two things to know:

- **This is only real if your CNI enforces NetworkPolicy.** Cilium, Calico and
  Antrea do; some managed CNIs and plain flannel do not. On a CNI that ignores
  policies the manifest is decoration.
- **Egress to an in-cluster model gateway needs an explicit rule**, because
  RFC1918 is excluded. See `values-examples/air-gapped.yaml`. The chart refuses
  to render a model endpoint on a `.svc`, `.cluster.local` or private address
  until `networkPolicy.egress.extra` has a rule for it, so this cannot fail
  silently at runtime.

## Configuration

`config.values` is rendered to `HERMES_HOME/config.yaml` by an init container,
`soul.text` to `SOUL.md`. `bootstrap.overwrite=true` (the default) makes Helm the
source of truth on every restart; set it to `false` to seed once and let the
agent own the file afterwards. `config.raw` takes a templated YAML string when
the structured form is not enough.

Two defaults differ from the Hermes sample configuration on purpose:

| Setting | Here | Why |
|---|---|---|
| `security.tirith_fail_open` | `false` | Upstream fails open: if the policy engine errors, the request proceeds unchecked. |
| `browser.allow_private_urls` | `false` | Second line of defence behind the NetworkPolicy - the browser tool should not fetch cluster-internal URLs. |

### Several model endpoints: switchable, with failover

`config.values.model` is the main model, and on its own it holds exactly one
endpoint. To keep two or more available at once - a hosted API and an
in-cluster gateway, say - declare each as a named entry under
`config.values.providers` and pick the main one by name:

```yaml
config:
  values:
    model:
      provider: salad
      default: qwen3.6-35b-a3b
      base_url: ""            # the endpoint comes from providers.salad
    providers:
      salad:
        api: https://ai.salad.cloud/v1
        key_env: SALAD_API_KEY
        discover_models: false
        models: [qwen3.6-35b-a3b]
      claude-code:
        api: http://claude-code-openai-wrapper.claude.svc:8000/v1
        key_env: CLAUDE_CODE_WRAPPER_API_KEY
        discover_models: false
        models: [claude-sonnet-4-6]
    fallback_providers:
      - provider: claude-code
        model: claude-sonnet-4-6
```

Every named provider is selectable: `/model` in Telegram, Discord or the
dashboard chat switches the current session between them, and the dashboard's
Models page lists each one with its `models`. `fallback_providers` is the
ordered chain Hermes moves to, mid-conversation, when the main model answers
429, 5xx, 401/403 or 404 - for the rest of that turn, then it retries the
primary on the next message. Swapping which endpoint is primary is a one-word
edit to `model.provider` (and a restart, since `bootstrap.overwrite=true`
re-seeds `config.yaml`). A fallback entry can also spell out `provider: custom`
with its own `base_url` and `key_env` instead of naming a provider.

Credentials never go in values: `key_env` names a key of the Secret the pod
mounts (`secrets.existingSecret`, the ExternalSecret target, or
`extraEnvFrom`), one per provider, and the chart refuses an inline `api_key`
anywhere on a model endpoint unless `hardening.allowInlineSecrets=true`. It
also refuses a `key_env` that nothing in the release puts on the pod, a
fallback entry missing `provider` or `model` (Hermes would drop it without a
word), a `model.base_url` that contradicts the named provider, and an
in-cluster endpoint with no `networkPolicy.egress.extra` rule.
`values-examples/multi-provider.yaml` is the complete version of the snippet
above, egress rule included.

## Giving the agent a browser

The image enables a `browser` toolset that attaches to a Chromium over the
DevTools Protocol at `http://127.0.0.1:9222`, and ships no browser binary. Until
something listens there the toolset is enabled with nothing behind it.

```bash
helm upgrade hermes oci://ghcr.io/ankraio/ankra-charts/hermes-agent \
  -n hermes --version 0.1.4 \
  --set secrets.existingSecret=hermes-credentials \
  --set browser.cdp.enabled=true
```

That runs a digest-pinned `chromedp/headless-shell` beside the agent in the same
pod: the debugger binds loopback, so the agent reaches it and the cluster cannot.
The container is non-root, unprivileged, read-only-root and drops every
capability; Chromium's own sandbox needs privileges this chart will not grant, so
`--no-sandbox` is passed and the container hardening carries the weight instead.

For browsers the built-in toolset cannot drive, use MCP. **Camoufox** - a
hardened Firefox whose fingerprint and input timing read as a person rather than
a headless robot - speaks Playwright, not CDP, so it cannot back the built-in
toolset and comes in as an MCP server instead (the other way to get Camoufox is
the REST-wrapped sidecar in [Camofox](#camofox-the-anti-detection-browser)
below, which replaces the built-in browser tools wholesale):

```yaml
mcp:
  servers:
    camoufox:
      command: npx
      args: ["-y", "@playwright/mcp@latest", "--browser=firefox", "--isolated"]
      env:
        PLAYWRIGHT_FIREFOX_EXECUTABLE_PATH: /opt/data/camoufox/camoufox
```

`mcp.servers` is rendered to `mcp.json` in the agent home by the same bootstrap
init container that seeds `config.yaml` and `SOUL.md`, in the exact shape the
agent validates (`$schema` and `mcpServers`, nothing else), so the server is live
on start and no `hermes mcp add` has to be run inside the pod. Its tools arrive
namespaced under the server name (`camoufox:browser_navigate`) and can be toggled
with `hermes tools enable|disable`. Both halves together are
[`values-examples/browser-stealth.yaml`](values-examples/browser-stealth.yaml).

Egress still goes through the NetworkPolicy, and `browser.allow_private_urls`
stays `false`: a browser in the pod does not become a way into the cluster.

## Exposing the API server

```bash
helm upgrade hermes oci://ghcr.io/ankraio/ankra-charts/hermes-agent \
  -n hermes --version 0.1.1 \
  --set secrets.existingSecret=hermes-credentials \
  --set apiServer.enabled=true \
  --set service.enabled=true
```

`apiServer.enabled=true` requires an `API_SERVER_KEY` in the Secret - the
OpenAI-compatible endpoint is unauthenticated without it. The Service, the
container port and the NetworkPolicy ingress rule are all derived from the
enabled listeners, so there is nothing else to keep in step. Enabling it also
installs `tcpSocket` liveness/readiness/startup probes; set `probes.*` to
replace them.

`ingress.enabled=true` and `virtualService.enabled=true` (Istio) route to the
first exposed port unless you set `servicePortNumber`.

## Storage

`HERMES_HOME` (`/opt/data`) holds conversation state, the seeded config and any
npm packages, on a `ReadWriteOnce` PVC. That makes the workload single-writer:
the chart refuses `replicaCount > 1` and refuses `RollingUpdate` while
persistence is on. For more agents, install more releases - one per agent, or
one per tenant with `values-examples/multi-tenant.yaml`.

Set `persistence.enabled=false` for a stateless gateway; the volume becomes an
`emptyDir` and the single-writer rules no longer apply.

## Camofox: the anti-detection browser

Hermes ships its own browser tools, driven by agent-browser (Chrome). Sites that
fingerprint their visitors see that for what it is. Upstream's answer is
[Camofox](https://github.com/jo-inc/camofox-browser): Camoufox, a Firefox fork
that spoofs its fingerprint in C++ rather than with JS shims, wrapped in a REST
API. **Setting `CAMOFOX_URL` makes Hermes route every one of its browser tools
through it**, in place of agent-browser and Browserbase.

```yaml
camofox:
  enabled: true
  image:
    digest: sha256:...   # required; see below
```

That runs Camofox as a second container in the same pod and points the agent at
`http://localhost:9377`. It is a sidecar rather than something inside the agent
container for two reasons: Camoufox needs GTK3, Mesa and Xvfb, none of which the
agent image ships, and it wants a writable home for profiles, cookies and
traces. Same pod also means loopback — no NetworkPolicy rule and no Service.

Point the agent at a Camofox you run elsewhere with `camofox.url` instead; the
sidecar is then unnecessary and `camofox.enabled` stays false.

Three things worth knowing before you turn it on:

- **The image is ours.** Upstream publishes none, so this repository builds
  `ghcr.io/ankraio/images/camofox-browser` from their pinned tag — see
  [`images/camofox-browser/`](../images/camofox-browser). It is amd64 only,
  because the Camoufox binary architecture is a build argument upstream.
- **It must be digest-pinned.** This container renders every page the agent
  visits, so a moved tag is a code-execution change; rendering fails without a
  digest unless you set `hardening.allowMutableImageTag=true`.
- **`camofox.securityContext` is weaker than the agent's**, deliberately and
  visibly: upstream bakes the Camoufox bundle into `/root/.cache/camoufox` and
  sets no `USER`, and Firefox wants a writable profile directory, so
  `runAsUser`/`runAsNonRoot`/`readOnlyRootFilesystem` are left unset rather than
  guessed. Tighten them in your own values once you have exercised the image.

## MCP servers

`mcp.servers` is the lane for any MCP server, not only browsers; each entry is
passed through to `mcp.json` as written:

```yaml
mcp:
  servers:
    filesystem:
      command: npx
      args: ["-y", "@modelcontextprotocol/server-filesystem", "/opt/data"]
npm:
  enabled: true
  packages:
    - "@modelcontextprotocol/server-filesystem"
```

`npm.enabled` matters: stdio servers need their package on disk, and the chart
installs `npm.packages` into the data volume at startup and puts them on `PATH`.
Leaving it off means `npx` fetches from the registry on every tool call.

The dashboard also carries a catalog of remote MCP servers that install with one
click and authenticate over OAuth per user — those are not chart configuration.

## Operator-ready mode

`operator.enabled=true` renders `HermesTenant` custom resources
(`hermes.ai/v1alpha1`) instead of a workload, for platforms that run their own
controller. **This chart does not ship a controller** - without one, the custom
resources sit there and nothing runs. The CRD lives in `crds/`, which Helm
installs but never upgrades or deletes; apply changes with
`kubectl apply --server-side -f hermes-agent/crds/`.

## Verifying a published chart

Every chart pushed to GHCR is signed with cosign (keyless, GitHub OIDC) and
carries an SPDX SBOM attestation:

```bash
cosign verify oci://ghcr.io/ankraio/ankra-charts/hermes-agent:0.1.1 \
  --certificate-identity-regexp '^https://github\.com/ankraio/ankra-charts/' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com

cosign verify-attestation --type spdxjson \
  oci://ghcr.io/ankraio/ankra-charts/hermes-agent:0.1.1 \
  --certificate-identity-regexp '^https://github\.com/ankraio/ankra-charts/' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com
```

The GitHub Pages repo publishes a cosign bundle next to each package, so HTTP
consumers can verify too:

```bash
curl -fsSLO https://ankraio.github.io/ankra-charts/hermes-agent-0.1.1.tgz
curl -fsSLO https://ankraio.github.io/ankra-charts/hermes-agent-0.1.1.tgz.cosign.bundle
cosign verify-blob hermes-agent-0.1.1.tgz \
  --bundle hermes-agent-0.1.1.tgz.cosign.bundle \
  --certificate-identity-regexp '^https://github\.com/ankraio/ankra-charts/' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com
```

## Relationship to the community chart

There is an unofficial community chart at
[`ultraworkers/hermes-agent-helm-chart`](https://github.com/ultraworkers/hermes-agent-helm-chart).
This is a separate implementation, not a fork: that repository publishes no Helm
index and carries no licence file, so Ankra maintains its own chart under
Apache-2.0 with the same feature surface and different defaults.

Behaviour worth knowing about if you are moving across:

| | Community chart | Here |
|---|---|---|
| Image | `nousresearch/hermes-agent:0.8.0` - **a tag that does not exist on Docker Hub**; the real tags are CalVer (`v2026.8.16`) | Real tag, pinned by digest |
| API keys | ~60 enumerated keys in `values.yaml`, meant to be filled in | Refused inline; `existingSecret` or ExternalSecret |
| Secret values | Passed through `tpl`, so a key containing `{{` is executed as a template | Written verbatim |
| ExternalSecret API | `external-secrets.io/v1beta1`, removed in ESO 0.17 | `external-secrets.io/v1`, configurable |
| NetworkPolicy | Off by default, raw rules only | On by default, metadata and RFC1918 excluded |
| Init containers | No resource requests or limits | Same requests and limits as the main container |
| npm installs | Runs lifecycle scripts from the public registry | Opt-in, `--ignore-scripts`, configurable registry |
| Values typos | Accepted silently | Rejected by `values.schema.json` |
| Guardrails | Docs | Render-time failures with named waivers |

## Values

See [`values.yaml`](values.yaml) for the annotated set and
[`values.schema.json`](values.schema.json) for the contract - unknown top-level
keys are rejected, so a typo fails the install instead of being ignored.

## Local development

```bash
helm lint hermes-agent
helm template hermes hermes-agent -n hermes -f hermes-agent/values-examples/production.yaml
helm unittest hermes-agent

# Re-resolve the pinned image digest from the registry.
./scripts/sync-image-digest.sh hermes-agent
```
